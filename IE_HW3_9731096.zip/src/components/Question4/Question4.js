import Calculator from './components/calculator';
export const Question4Component = () => {
    return (
        <div className="Q4">
            <h1>سوال ۴</h1>
            <Calculator />
        </div>
    );
};
