import { UserList } from './components/UserList/UserList';
export const Question3Component = () => {
    return (
        <div className="Q3">
            <h1>سوال ۳</h1>
            <UserList />
        </div>
    );
};
