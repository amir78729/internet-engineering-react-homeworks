export const colors = {
    YELLOW : '#ffc107',
    RED: '#dc3545',
    BLUE: '#007bff',
    GREEN: '#28a745'
};